# Marabunta-Interior
![Marabunta Interior](https://repository-images.githubusercontent.com/200735083/649eca80-b7e6-11e9-9bd8-4191bc64c783)
Video: https://youtu.be/A9s7RNU96Fo
# Installation
1. Add the `marabuntaint` folder to your FiveM resources directory.
2. Inside the **server.cfg** file type `start marabuntaint`.
